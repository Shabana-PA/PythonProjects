from django.contrib import admin

from . models import Place
from . models import District

# Register your models here.
admin.site.register(District)
admin.site.register(Place)