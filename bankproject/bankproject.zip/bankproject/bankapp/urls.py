# bankapp/urls.py
from django.urls import path
from . import views
app_name = 'bankapp'

urlpatterns = [
    path('', views.get_places, name='get_places'),  # This is the root path
]
