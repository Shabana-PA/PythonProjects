# views
from django.shortcuts import render, redirect
from .models import Place, District


def get_places(request):
    districts = District.objects.all()  # Replace with your District model queryset
    places = []  # Initially, places will be an empty list
    selected_district = None  # Initialize selected_district

    if request.method == 'POST':
        selected_district_id = request.POST.get('district')
        if selected_district_id:
            selected_district = District.objects.get(pk=selected_district_id)

            # Check if the selected district has any places
            if selected_district.places.all().count() > 0:
                places = selected_district.places.all()

    return render(request, 'home.html', {'districts': districts, 'places': places, 'selected_district': selected_district})
