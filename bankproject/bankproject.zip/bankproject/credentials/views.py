from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib import auth
from django.contrib.auth.models import User
from django.shortcuts import render, redirect

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return redirect('home')  # Redirect to the home page or another appropriate view
        else:
            messages.error(request, "Invalid credentials")
            return redirect('login')

    return render(request, "login.html")


def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        fname = request.POST['first_name']
        lname = request.POST['last_name']
        email = request.POST['email']
        password = request.POST['password']
        cpassword = request.POST['password1']

        if password == cpassword:
            if User.objects.filter(username=username).exists():
                messages.error(request, "Username Taken")
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.error(request, "Email Taken")
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, password=password, first_name=fname, last_name=lname, email=email)
                user.save()
                messages.success(request, "Registration successful. You can now log in.")
                return redirect('login')  # Redirect to the login page
        else:
            messages.error(request, "Passwords do not match")
            return redirect('register')

    return render(request, "register.html")

@login_required
def logout(request):
    auth.logout(request)
    return redirect('login')  # Redirect to the login page after logout
